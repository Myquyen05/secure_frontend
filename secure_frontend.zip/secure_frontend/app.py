from flask import Flask, request, render_template, send_from_directory, redirect, url_for
from cryptography.fernet import Fernet
import os

app = Flask(__name__)

# Thư mục lưu file đã mã hóa
UPLOAD_FOLDER = '/mnt/secure_volume'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Khóa mã hóa cố định (hoặc load từ file)
KEY = b'TWnEVPB9EQfKDi0FuAZHozHhyQUDUkqgMt4MR1_M42s='  # 🔐 Lưu ý: key này phải giữ bí mật
cipher = Fernet(KEY)

# Trang chính
@app.route('/')
def index():
    files = os.listdir(app.config['UPLOAD_FOLDER'])
    return render_template('index.html', files=files)

# Upload và mã hóa
@app.route('/upload', methods=['POST'])
def upload():
    file = request.files['file']
    filename = request.form.get('filename', '').strip()

    if not filename or not filename.isalnum():
        return '❌ Tên file không hợp lệ. Chỉ dùng ký tự a-z, A-Z, 0-9.'

    encrypted_filename = filename + '.enc'
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], encrypted_filename)

    # Mã hóa nội dung
    encrypted_data = cipher.encrypt(file.read())
    with open(filepath, 'wb') as f:
        f.write(encrypted_data)

    return redirect(url_for('index'))

# Tải file đã mã hóa
@app.route('/download/<filename>')
def download(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename, as_attachment=True)

# Giải mã file và tải về bản gốc
@app.route('/decrypt/<filename>')
def decrypt(filename):
    enc_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)

    if not os.path.exists(enc_path):
        return '❌ File không tồn tại.'

    # Giải mã nội dung
    with open(enc_path, 'rb') as f:
        encrypted_data = f.read()

    try:
        decrypted_data = cipher.decrypt(encrypted_data)
    except Exception as e:
        return f'❌ Giải mã thất bại: {str(e)}'

    # Tạo tên mới cho file giải mã
    original_name = filename.replace('.enc', '_decrypted')
    dec_path = os.path.join(app.config['UPLOAD_FOLDER'], original_name)

    with open(dec_path, 'wb') as f:
        f.write(decrypted_data)

    return send_from_directory(app.config['UPLOAD_FOLDER'], original_name, as_attachment=True)

# Khởi chạy Flask
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)

